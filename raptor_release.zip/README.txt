Made by Spacek

The three rides in this release are identical except for graphics of the front car.

The official object is included for completeness because the object has not yet been merged into the official repository and distributed that way. Once it is officially distributed, there is no reason to install this object manually.

-----------------------

To install the objects:

place RAPTWWLC.DAT and RAPTDLCS.DAT in the OpenRCT2/bin folder

place official.rmct2.parkobj in the OpenRCT2/bin/data/object/data/official/ride folder to allow it to be replaced with the official object when it is distributed officially

-----------------------

To use the objects:

Set the filter to allow Custom objects and find RAPTWWLC.DAT and RAPTDLCS.DAT under 'Single Rail Roller Coaster'

Set the filter to allow Official objects and find official.rmct2.parkobj under 'Single Rail Roller Coaster'