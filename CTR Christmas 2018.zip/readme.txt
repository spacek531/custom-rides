Hello! Thank you for downloading CTR Christmas 2018!

I've put a lot of work into making this the best Christmas gift I can imagine, and I hope you enjoy thoroughly! Included are 35 Custom Tracked Ride objects, 4 scenery objects, and 2 parks for RCT2. 

The "CTR Christmas 2018 Easy Install" includes every object included in the release, so running that will give you every object right away. If you wanted to look at each object individually, they are organized by present - City Essentials, Toybox Pack, and Spacecrab Collection.

The City Essentials: Part 1 pack is made for city planners of all stripes. With 7 vehicles to choose from, you can create the urban centers, industrial complexes, and country lifestyles to compliment your parks.

The Toybox pack is made for the kid in all of us. With several toy- and kid-themed rides, your bedroom parks will be better than ever.

The Spacecrabs Collection is a celebration of the new and innovative rides created during Spacecrab's Head 2 Head Season 8. Including every ride released under the Spacecrab banner, there are several bonus features in this gift. First is an unreleased Spacecrabs ride that was meant to be included in Mount Haystack. This unreleased ride, called "Advanced Ski and Snowboarders," has peeps perform tricks when traveling on banked tracks and a modified version of Mount Haystack featuring this ride. Also included are "summer" versions of the quad lift and gondola. These versions have no skis or snowboards; they are perfect for every other time of year.

To those who were expecting one ride per present, I hope you were blown away by the amount of content and its quality this year. Please enjoy, and have a very merry Christmas!